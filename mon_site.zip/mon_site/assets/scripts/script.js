// Script de base pour des interactions futures
document.addEventListener("DOMContentLoaded", () => {
    console.log("Bienvenue sur le site de Draïthius !");
});
