// Sélection des éléments du DOM
const form = document.getElementById("comment-form");
const commentSection = document.getElementById("comment-section");

// Charger les commentaires depuis localStorage
const loadComments = () => {
    const comments = JSON.parse(localStorage.getItem("comments")) || [];
    comments.forEach(({ username, text }) => {
        addCommentToDOM(username, text);
    });
};

// Ajouter un commentaire au DOM
const addCommentToDOM = (username, text) => {
    const commentDiv = document.createElement("div");
    commentDiv.classList.add("commentaire");
    commentDiv.innerHTML = `
        <p><strong>${username}</strong>: "${text}"</p>
        <button class="delete-btn">Supprimer</button>
    `;
    commentSection.appendChild(commentDiv);

    // Gérer la suppression des commentaires
    commentDiv.querySelector(".delete-btn").addEventListener("click", () => {
        commentDiv.remove();
        saveComments();
    });
};

// Sauvegarder les commentaires dans localStorage
const saveComments = () => {
    const comments = Array.from(document.querySelectorAll(".commentaire")).map((comment) => {
        const username = comment.querySelector("strong").textContent;
        const text = comment.querySelector("p").textContent.split(": ")[1].replace(/"/g, "");
        return { username, text };
    });
    localStorage.setItem("comments", JSON.stringify(comments));
};

// Gestion de l'envoi du formulaire
form.addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value.trim();
    const text = document.getElementById("comment-text").value.trim();

    if (username === "" || text === "") {
        alert("Veuillez remplir tous les champs !");
        return;
    }

    // Ajouter le commentaire à l'affichage
    addCommentToDOM(username, text);

    // Sauvegarder dans localStorage
    saveComments();

    // Réinitialiser le formulaire
    form.reset();
});

// Charger les commentaires au démarrage
loadComments();
